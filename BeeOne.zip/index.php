<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title></title>
	<link type="image/x-icon" rel="shortcut icon" href="img/favicon.png">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/font-awesome.min.css" rel="stylesheet">
<!--   googlefonts -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" integrity="sha512-tS3S5qG0BlhnQROyJXvNjeEM4UpMXHrQfTGmbQ1gKmelCxlSEBUaxhRBj/EFTzpbP4RVSrpEikbmdJobCvhE3g==" crossorigin="anonymous" />
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    
    <!-- header section start-->
        <header>
        <div class="container-fluid">
        <img class="logo" src="img/logo.png" alt="logo" /><div class="visible-xs toggle-b">
          <div id="nav-icon0">
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
  <span></span>
</div></div>
        <div class="right-hed">
        <div class="bell">
        <i class="fa fa-bell-o" aria-hidden="true"></i>
        </div><!-- bell -->
        <div class="profile">
        <div class="dropdown">
        <button class="dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown">
        <div class="media">
        <img class="mr-3 pull-left" src="img/profile.png" alt=""/>
        <div class="media-body">
        <h5 class="mt-0"><span>Subash Manual</span><i class="fa fa-angle-down" aria-hidden="true"></i></h5> 
        </div>
        </div>
        </button>
        <ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu1">
        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Profile</a></li>
        <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Log out</a></li>
        </ul>
        </div>
        </div><!-- profile -->
        </div><!-- right-hed -->

        </div><!-- container-fluid -->
        </header>
        <!-- header section end-->
    
    

    <section class="content">
      <div class="container">
        
          
          <div class="slide-panel">
            <ul>
              <li><a href="#" class="active"><img src="img/icon1.png" alt=""><span>Dashbord</span></a></li>
              <li><a href="#"><img src="img/icon3.png" alt=""><span>E Wallets</span></a></li>
              <li><a href="#"><img src="img/icon2.png" alt=""><span>Affiliates</span></a></li>
              <li><a href="#"><img src="img/icon4.png" alt=""><span>Events</span></a></li>
              <li><a href="#"><img src="img/icon5.png" alt=""><span>Payments</span></a></li>
              <li><a href="#"><img src="img/icon.png" alt=""><span>Manage my Business</span></a></li>
              <li><a href="#"><img src="img/icon7.png" alt=""><span>Settings</span></a></li>
            </ul>
          </div><!-- slide-panel -->

          <div class="row">
          <div class="pad-bx">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <a href="#" class="refer">Refer a Friend <img src="img/refer.png" alt=""></a><!-- refer -->
            </div><!-- col-12 -->
            <div class="col-md-8 col-sm-12 col-xs-12">
              <div class="row">
               
                   <h2 class="alt"><span></span>Portfolio</h2>
              <div class="graph-con">
                 <div class="col-md-7 col-sm-6 col-xs-12">
                   <div id="container" style="height: auto; width: 100%"></div>
                    </div><!-- col-8 -->
                    <div class="col-md-5 col-sm-6 col-xs-12 pad-right-none">
                      <div class="run-port">
                          
                          <div class="progress blue">
                <span class="progress-left">
                    <span class="progress-bar"></span>
                </span>
                <span class="progress-right">
                    <span class="progress-bar"></span>
                </span>
                <div class="progress-value">90%</div>
            </div>



                  <h4>CCRB Mining</h4>
                  <h5>Overall Completion</h5>
                  <div class="row">
                    <div class="col-md-6 col-xs-6 col-sm-6 pad-left-none">
                      <h6>Hashes Mined<br><span>985K</span></h6>
                    </div><!-- col-6 -->
                      <div class="col-md-6 col-xs-6 col-sm-6 pad-left-none">
                      <h6>CCRB Mined<br><span>$ 2.46</span></h6>
                    </div><!-- col-6 -->
                  </div><!-- row -->
                      </div><!-- run-port -->
                    </div><!-- col-5 -->
              </div><!-- graph-con -->
               
            </div><!-- row -->
            </div><!-- col-7 -->
            <div class="col-md-4 pad-left-75 col-sm-8 col-xs-12">
              <div class="card-con">
                <img src="img/card.png" alt="" style="width: 100%;">
                <ul>
                  <li><span>Membership :</span><a href="#" style="color: #3389fb;">Prime Plus</a></li>
                  <li><span>Trading Account :</span><a href="#">266.7 CCRB</a></li>
                  <li><span>Mining Balance :</span><a href="#">266.7 CCRB</a></li>
                  <li><span>Mining Pending:</span><a href="#">266.7 CCRB</a></li>
                  <li><span>Total</span><a href="#">266.7 CCRB</a></li>
                </ul>
                <a href="#" class="refer">Upgrade</a>
              </div><!-- card-con -->
            </div><!-- col-4 -->



      <div class="owl-con">
        <span class="owl-nav">
                  <span class="owl-next" id="blg-next"><img src="img/right.png"></span>
          </span>

      <div class="owl-carousel" id="blg">

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide2.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide1.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide4.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide3.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide2.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

          <div class="item">
          <div class="media">
          <img class="mr-3 pull-left wow fadeInUp" data-wow-duration="1s" data-wow-delay="1.1s" src="img/slide1.png" alt="">
          <div class="media-body">
          <h5 class="mt-0">CyptoCarbon (CCRB)

          <span>266.7 CCRB</span>
          </h5>  
          </div>
          </div>
          </div><!-- item -->

      </div>
      </div><!-- owl-con -->


          </div><!-- pad-bx -->
        </div><!-- row -->
      </div><!-- container -->
    </section><!-- content -->
   
   
   <!-- footer section start --> 
   <footer>
   		
        
        
   </footer>
   <!-- footer section end -->
    
    

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
     <script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
	<script src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" integrity="sha512-bPs7Ae6pVvhOSiIcyUClR7/q2OAsRiovw4vAkX+zJbw3ShAeeqezq50RIIcIURq7Oa20rW2n2q+fyXBNcU9lrw==" crossorigin="anonymous"></script>
    


    <script src="js/custom.js"></script>
     <script src="https://code.highcharts.com/highcharts.src.js"></script>


    <script type="text/javascript">
  
        // notification icon active

        $('header .bell').click(function() {
        $("i", this).toggleClass("fa fa-bell-o fa fa-bell active");
        });



      $(document).ready(function(){

      $(".content .slide-panel").hover(function(){
      $(".pad-bx").toggleClass("pd");  //Toggle the active class to the area is hovered
      });

      });




        $('.visible-xs.toggle-b').click(function() {
         $(".content .slide-panel").toggleClass("show"); 
        });







var chart = new Highcharts.Chart({
  chart: {

    renderTo: 'container',
    marginBottom: 40,
    marginTop:120,
    marginLeft:0
  },
   title: {
    text: 'Your Portfolio Value',
    marginTop:80
},
subtitle: {
    text: '0.00 BTC',
    y:50
},
  xAxis: {
    categories: ['12 Jun', '14 Jun', '16 Jun', '18 Jun', '20 Jun', '22 Jun', '24 Jul', '25 Jul' ],
    labels: {
      rotation: 0
    }

  },


  series: [{
    data: [0, 200, 450, 600, 700, 1050, 1250,  1450, 1750]        
  }]
});





$(document).ready(function(){
  $('#nav-icon0').click(function(){
    $(this).toggleClass('open');
  });
});

    </script>




<script type="text/javascript">

   var blg = $('#blg').owlCarousel({
    loop:true,
    margin:35,
    autoplay: true,
            slideTransition: 'linear',
            autoplayTimeout: 6000,
            autoplaySpeed: 6000,
            autoplayHoverPause: true,
    responsiveClass:true,
    responsive:{
        0:{
            items:1,
           
        },
        600:{
            items:2,
            
        },
        1000:{
            items:3,
        },
        1050:{
           items:4,
        }
    }
})

$('#blg-prev').click(function() {
    blg.trigger('next.owl.carousel');
})
// Go to the previous item
$('#blg-next').click(function() {
    // With optional speed parameter
    // Parameters has to be in square bracket '[]'
    blg.trigger('prev.owl.carousel', [300]);
})
</script>




  </body>
</html>